#' RidSEMM
#'
#' RidSEMM
#' @param lam lam
#' @param X X
#' @param y y
#' @param deltaesc deltaesc
#' @param nkeep nkeep
#' @param keff keff
#' @return Create
#' @export

RidSEMM<-function(lam,X,y,deltaesc=0.5,nkeep=5,keff){

  #Compute Pena Yohai, S-estimator and M-scale estimator
  temp=PeYoRid(X,y,lam,deltaesc,nkeep)
  betaSE=temp$betamin ; residSE=temp$resid ; sigma=temp$sigma
  edfSE=temp$edf

  if(missing(keff)){#Correction
    psn=edfSE/length(y)
    if(psn<0.1){keff=3.5}
    else if(psn<0.2){keff=3.77}
    else if (psn<0.33){keff=4}
    else {keff=4}
  }

  #Compue MM estimator
  temp=MMRid(X,y,lam,betaSE,sigma,keff)
  betaMM=temp$beta ; residMM=temp$res ; edfMM=temp$edf ; w=temp$w ; kasig=temp$kasig
  result<-list(betaSE=betaSE,betaMM=betaMM,residSE=residSE,residMM=residMM,edfSE=edfSE,
               edfMM=edfMM,kasig=kasig,sigma=sigma)
  return(result)
}

