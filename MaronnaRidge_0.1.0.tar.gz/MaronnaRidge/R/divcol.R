#' divcol
#'
#' divcol
#' @param X X
#' @param sig sig
#' @return Create
#' @import stats
#' @export

divcol<-function(X,sig){
  n=dim(X)[1]; p=dim(X)[2]
  if(missing(sig)){
    sig=matrix(apply(X,2,sd),1,p)
  }
  return(X/(matrix(1,n,1)%x%sig))
}
