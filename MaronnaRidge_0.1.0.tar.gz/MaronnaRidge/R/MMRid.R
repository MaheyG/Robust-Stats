#' MMRid
#'
#' MMRid
#' @param X X
#' @param y y
#' @param lam lam
#' @param betin betin
#' @param sigma sigma
#' @param kefi kefi
#' @param niter niter
#' @param tol tol
#' @return Create
#' @import matrixStats
#' @export


MMRid<-function(X,y,lam,betin,sigma,kefi=3.88,niter=50,tol=1.e-3){
  n=dim(X)[1]; p=dim(X)[2]
  kasig=kefi*sigma
  betinte=betin[p+1]
  betinslo=betin[1:p]
  res0=y-X%*%betinslo-betinte #Y-XB-B_0
  crit0=kasig^2*sum(rho(res0/kasig))+lam*sum(betinslo^2)

  #Iteration
  iter=0;delta=Inf;conve=Inf;
  binter=betinte #Beta of the iteration
  while((iter<niter) && ((delta>tol) ||(conve>tol))){ #atain the max of iteration && convergence criterium
    iter=iter+1
    tt=res0/kasig
    w=weights(tt)
    rw=sqrt(w)
    ycen=y-binter
    Xw=X*(matrix(1,1,p)%x%rw) # X * Matrix of rw as column(Kronecker product)->normalize the column of X
    yw=ycen*rw
    Xau=rbind(Xw,sqrt(lam)*diag(p)) #Add raw-> Xau in M_(n+p)xp
    yau=rbind(yw,matrix(0,p,1)) #Add raw -> yau in R^(n+p)
    beta=matrix(lsfit(Xau,yau, intercept = FALSE)$coeff) #RESOLVE THE SYSTEM yau=Xaubeta in ls sense
    resin=y-X%*%beta
    if(sum(w)>0){binter=sum(resin*w)/sum(w)
    }
    else {binter=colMedians(resin)
    }
    res=resin-binter #centered residuals
    crit=kasig^2*sum(rho(res/kasig))+lam*sum(beta^2)
    deltold=delta
    delta=1-crit/crit0
    conve=max(abs(res-res0))/sigma #Measure convergence of residuals
    res0=res0;crit0=crit
  }
  beta=rbind(beta,binter)
  hmat=Xau%*%(lsfit(t(Xau)%*%Xau,t(Xau),intercept = FALSE)$coeff)
  h=diag(hmat)
  edf=sum(h[1:n])
  result<- list(beta=beta,res=res,edf=edf,w=w,kasig=kasig)
  return(result)
}

#' rho
#'
#' rho
#' @return Create
#' @export

rho<-function(t){ #To make rho''(0)=2
  s=(1-(1-s^2)^3*abs(s)<=1)/3
}

#' weights
#'
#' wheights
#' @param r r
#' @return Create
#' @export
weights<-function(r){ #w=(psibis(r)/r)/2 to eliminate the 2 from 2*lam
  w=(abs(r)<=1)*(1-r^2)^2
}


