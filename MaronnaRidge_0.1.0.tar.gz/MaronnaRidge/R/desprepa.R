#' desprepa
#'
#' desprepa
#' @param beta0 beta0
#' @param mux mux
#' @param sigx sigx
#' @param muy muy
#' @return Create
#' @export

desprepa<-function(beta0,mux,sigx,muy){
  beta<-beta0/t(sigx)
  bettint=muy-t(matrix(mux))%*%beta
  beta=rbind(beta,bettint)
  return(beta)
}
